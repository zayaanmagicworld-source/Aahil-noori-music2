import { type ReactNode, useEffect, useMemo, useRef, useState } from 'react';
import {
  ClerkProvider,
  SignIn,
  SignInButton,
  SignUp,
  SignUpButton,
  SignedIn,
  SignedOut,
  useAuth,
  useClerk,
  useUser,
} from '@clerk/react';
import { publishableKeyFromHost } from '@clerk/react/internal';
import { shadcn } from '@clerk/themes';
import {
  Archive,
  Bell,
  Bookmark,
  Check,
  ChevronDown,
  Clock3,
  Disc3,
  Heart,
  Home as HomeIcon,
  Library,
  ListMusic,
  Menu,
  MessageCircle,
  Mic2,
  MoreHorizontal,
  Music2,
  Play,
  Plus,
  Radio,
  Search,
  Send,
  Share2,
  Sparkles,
  Upload,
  Video,
  Volume2,
  VolumeX,
  X,
  Zap,
} from 'lucide-react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import NotFound from '@/pages/not-found';
import { Link, Route, Switch, useLocation, Router as WouterRouter } from 'wouter';
import {
  fetchLibrary,
  fetchStoredMedia,
  setLibrarySaved,
  setMediaLiked,
  uploadMedia,
  type StoredMedia,
} from '@/lib/persistent-api';

const queryClient = new QueryClient();

type Track = {
  id: string;
  title: string;
  artist: string;
  meta: string;
  image: string;
  duration: string;
  kind: 'Song' | 'Video' | 'Short' | 'Live';
  accent: string;
  mediaUrl?: string;
  posterUrl?: string;
  persistentId?: string;
  mediaType?: StoredMedia['mediaType'];
};

const tracks: Track[] = [
  { id: 'noor-e-ishq', title: 'Noor-e-Ishq', artist: 'Aahil Noori', meta: '1.8M plays • 2 weeks ago', image: 'https://images.pexels.com/photos/164829/pexels-photo-164829.jpeg?auto=compress&cs=tinysrgb&w=1200', duration: '4:12', kind: 'Video', accent: '#ed704e' },
  { id: 'khwaab', title: 'Khwaab', artist: 'Aahil Noori', meta: '942K plays • 5 days ago', image: 'https://images.pexels.com/photos/1763075/pexels-photo-1763075.jpeg?auto=compress&cs=tinysrgb&w=1000', duration: '3:47', kind: 'Song', accent: '#f5c35c' },
  { id: 'raag-rain', title: 'Raag In The Rain', artist: 'Mahi Raza', meta: '228K plays • yesterday', image: 'https://images.pexels.com/photos/1671325/pexels-photo-1671325.jpeg?auto=compress&cs=tinysrgb&w=1000', duration: '5:08', kind: 'Live', accent: '#78b7a8' },
  { id: 'sajni-re', title: 'Sajni Re', artist: 'Aahil Noori', meta: '671K plays • 1 month ago', image: 'https://images.pexels.com/photos/1105666/pexels-photo-1105666.jpeg?auto=compress&cs=tinysrgb&w=1000', duration: '3:26', kind: 'Video', accent: '#df8870' },
  { id: 'midnight-riyaaz', title: 'Midnight Riyaaz', artist: 'Zoya Mir', meta: '184K plays • 3 days ago', image: 'https://images.pexels.com/photos/1389429/pexels-photo-1389429.jpeg?auto=compress&cs=tinysrgb&w=1000', duration: '6:31', kind: 'Song', accent: '#897ba9' },
  { id: 'awaaz-short', title: 'Awaaz / one take', artist: 'Samir Khan', meta: '85K views • 8 hours ago', image: 'https://images.pexels.com/photos/1190297/pexels-photo-1190297.jpeg?auto=compress&cs=tinysrgb&w=800', duration: '0:42', kind: 'Short', accent: '#e9a447' },
  { id: 'mehfil-session', title: 'Mehfil Session 04', artist: 'The Noori Collective', meta: '312K views • 2 weeks ago', image: 'https://images.pexels.com/photos/1763073/pexels-photo-1763073.jpeg?auto=compress&cs=tinysrgb&w=1000', duration: '14:05', kind: 'Live', accent: '#7192b5' },
  { id: 'tum-se', title: 'Tum Se Milke', artist: 'Mahi Raza', meta: '409K plays • 1 week ago', image: 'https://images.pexels.com/photos/154147/pexels-photo-154147.jpeg?auto=compress&cs=tinysrgb&w=1000', duration: '4:43', kind: 'Song', accent: '#d88172' },
];

const singers = [
  { name: 'Aahil Noori', role: 'The host', image: 'https://images.pexels.com/photos/1043474/pexels-photo-1043474.jpeg?auto=compress&cs=tinysrgb&w=500', color: '#ed704e' },
  { name: 'Mahi Raza', role: 'Sufi / indie', image: 'https://images.pexels.com/photos/733872/pexels-photo-733872.jpeg?auto=compress&cs=tinysrgb&w=500', color: '#e2b34f' },
  { name: 'Zoya Mir', role: 'Late night soul', image: 'https://images.pexels.com/photos/1181686/pexels-photo-1181686.jpeg?auto=compress&cs=tinysrgb&w=500', color: '#78b7a8' },
  { name: 'Samir Khan', role: 'New voices', image: 'https://images.pexels.com/photos/614810/pexels-photo-614810.jpeg?auto=compress&cs=tinysrgb&w=500', color: '#a884a4' },
];

const categories = ['For you', 'Songs', 'Videos', 'Shorts', 'Live sessions', 'Sufi nights'];
const sampleVideoUrl = `${import.meta.env.BASE_URL}media/aahil-noori-demo.mp4`;
const sampleVideoPoster = `${import.meta.env.BASE_URL}media/aahil-noori-demo-poster.jpg`;
const basePath = import.meta.env.BASE_URL.replace(/\/$/, '');
const clerkPubKey = publishableKeyFromHost(
  window.location.hostname,
  import.meta.env.VITE_CLERK_PUBLISHABLE_KEY,
);
const clerkProxyUrl = import.meta.env.VITE_CLERK_PROXY_URL;

async function sharePage(title: string, onNotice: (message: string) => void) {
  const shareData = {
    title,
    text: `Listen to ${title} on Aahil Noori`,
    url: window.location.href,
  };

  try {
    if (typeof navigator.share === 'function') {
      await navigator.share(shareData);
      onNotice('Shared from Aahil Noori');
      return;
    }

    if (navigator.clipboard?.writeText) {
      await navigator.clipboard.writeText(shareData.url);
      onNotice('Link copied to clipboard');
      return;
    }

    const helper = document.createElement('textarea');
    helper.value = shareData.url;
    helper.setAttribute('readonly', '');
    helper.style.position = 'fixed';
    helper.style.opacity = '0';
    document.body.appendChild(helper);
    helper.select();
    document.execCommand('copy');
    helper.remove();
    onNotice('Link copied to clipboard');
  } catch (error) {
    if (error instanceof DOMException && error.name === 'AbortError') return;
    onNotice('Copy the page link to share it');
  }
}

function IconButton({ children, label, onClick, active = false }: { children: ReactNode; label: string; onClick?: () => void; active?: boolean }) {
  return <button type="button" aria-label={label} title={label} onClick={onClick} data-testid={`button-${label.toLowerCase().replaceAll(' ', '-')}`} className={`focus-ring inline-flex h-10 w-10 items-center justify-center rounded-full transition-all ${active ? 'bg-[#ed704e] text-[#fffaf3]' : 'text-[#6e7180] hover:bg-[#eee4d8] hover:text-[#252941]'}`}>{children}</button>;
}

function NavItem({ icon, label, active, onClick }: { icon: ReactNode; label: string; active?: boolean; onClick: () => void }) {
  return <button type="button" data-testid={`nav-${label.toLowerCase().replaceAll(' ', '-')}`} onClick={onClick} className={`focus-ring flex w-full items-center gap-3 rounded-xl px-3 py-3 text-left text-sm font-semibold transition-all ${active ? 'bg-[#ed704e] text-[#fffaf3] shadow-[0_8px_20px_rgba(237,112,78,.2)]' : 'text-[#c8cad2] hover:bg-[#30344c] hover:text-[#fffaf3]'}`}>{icon}<span>{label}</span>{active && <span className="ml-auto h-1.5 w-1.5 rounded-full bg-[#f5c35c]" />}</button>;
}

function PlayButton({ onClick, small = false }: { onClick: () => void; small?: boolean }) {
  return <button type="button" onClick={onClick} aria-label="Play track" data-testid="button-play-track" className={`focus-ring absolute ${small ? 'bottom-2 right-2 h-9 w-9' : 'bottom-4 right-4 h-12 w-12'} flex items-center justify-center rounded-full bg-[#ed704e] text-[#fffaf3] shadow-[0_8px_18px_rgba(143,50,31,.3)] transition-transform hover:scale-105 active:scale-95`}><Play size={small ? 15 : 19} fill="currentColor" /></button>;
}

function TrackCard({ track, onPlay, liked, onLike, saved, onSave }: { track: Track; onPlay: (track: Track) => void; liked: boolean; onLike: (id: string) => void; saved: boolean; onSave: (id: string) => void }) {
  return <article data-testid={`card-track-${track.id}`} className="group min-w-0">
    <div className="cover-shine relative aspect-[1.58] overflow-hidden rounded-2xl bg-[#ddd0c3]">
      <img src={track.image} alt={`${track.title} cover`} className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105" />
      <div className="absolute inset-0 bg-gradient-to-t from-[#252941]/70 via-transparent to-transparent opacity-80" />
      <span className="absolute left-3 top-3 rounded-md bg-[#252941]/75 px-2 py-1 text-[10px] font-bold uppercase tracking-[.14em] text-[#fffaf3] backdrop-blur">{track.kind}</span>
      <span className="absolute bottom-3 left-3 font-mono text-[11px] font-medium text-[#fffaf3]">{track.duration}</span>
      <PlayButton small onClick={() => onPlay(track)} />
    </div>
    <div className="flex items-start gap-2 pt-3">
      <div className="min-w-0 flex-1"><h3 className="truncate text-[15px] font-bold text-[#252941]">{track.title}</h3><p className="truncate pt-1 text-xs text-[#777582]">{track.artist} <span className="text-[#b3a99e]">•</span> {track.meta.split('•')[0]}</p></div>
      <div className="flex shrink-0 items-center gap-0.5">
        <IconButton label={`like-${track.id}`} active={liked} onClick={() => onLike(track.id)}><Heart size={16} fill={liked ? 'currentColor' : 'none'} /></IconButton>
        <IconButton label={`save-${track.id}`} active={saved} onClick={() => onSave(track.id)}><Bookmark size={16} fill={saved ? 'currentColor' : 'none'} /></IconButton>
      </div>
    </div>
  </article>;
}

function Sidebar({ active, setActive, onUpload }: { active: string; setActive: (v: string) => void; onUpload: () => void }) {
  return <aside className="aahil-sidebar fixed inset-y-0 left-0 z-30 hidden w-[224px] flex-col px-4 py-6 lg:flex">
    <div className="mb-10 flex items-center gap-3 px-2"><div className="relative flex h-10 w-10 items-center justify-center rounded-2xl bg-[#ed704e] text-[#252941]"><Mic2 size={20} strokeWidth={2.5} /><span className="absolute -right-1 -top-1 h-2.5 w-2.5 rounded-full bg-[#f5c35c]" /></div><div><div className="aahil-display text-[17px] font-extrabold tracking-[-.08em] text-[#fffaf3]">aahil noori</div><div className="aahil-mono text-[8px] uppercase tracking-[.2em] text-[#a5a8b5]">music channel</div></div></div>
    <p className="mb-3 px-3 text-[10px] font-bold uppercase tracking-[.18em] text-[#7f8396]">Discover</p>
    <nav className="space-y-1">
      <NavItem label="Home" icon={<HomeIcon size={18} />} active={active === 'Home'} onClick={() => setActive('Home')} />
      <NavItem label="Songs" icon={<Music2 size={18} />} active={active === 'Songs'} onClick={() => setActive('Songs')} />
      <NavItem label="Videos" icon={<Video size={18} />} active={active === 'Videos'} onClick={() => setActive('Videos')} />
      <NavItem label="Shorts" icon={<Zap size={18} />} active={active === 'Shorts'} onClick={() => setActive('Shorts')} />
    </nav>
    <p className="mb-3 mt-9 px-3 text-[10px] font-bold uppercase tracking-[.18em] text-[#7f8396]">Your space</p>
    <nav className="space-y-1"><NavItem label="Library" icon={<Library size={18} />} active={active === 'Library'} onClick={() => setActive('Library')} /></nav>
    <div className="mt-auto rounded-2xl border border-[#42465c] bg-[#2c3047] p-4"><div className="mb-3 flex h-8 w-8 items-center justify-center rounded-xl bg-[#f5c35c] text-[#252941]"><Upload size={15} /></div><p className="text-sm font-bold text-[#fffaf3]">Have a song?</p><p className="mt-1 text-xs leading-relaxed text-[#aeb1bc]">Put your voice in the room.</p><button type="button" onClick={onUpload} data-testid="button-upload-sidebar" className="mt-4 flex w-full items-center justify-center gap-2 rounded-lg bg-[#ed704e] py-2.5 text-xs font-bold text-[#fffaf3] transition hover:bg-[#f17e5e]"><Plus size={14} /> Upload</button></div>
    <div className="mt-6 flex items-center gap-2 px-2"><div className="flex h-7 w-7 items-center justify-center rounded-full bg-[#e6b4a0] text-[10px] font-bold text-[#252941]">AN</div><span className="text-xs text-[#aeb1bc]">Aahil Noori</span><MoreHorizontal className="ml-auto text-[#7f8396]" size={16} /></div>
  </aside>;
}

function MobileNav({ active, setActive }: { active: string; setActive: (v: string) => void }) {
  return <nav className="fixed inset-x-0 bottom-0 z-40 flex items-center justify-around border-t border-[#e4d9cc] bg-[#faf4eb]/95 px-2 pb-[env(safe-area-inset-bottom)] pt-2 backdrop-blur-lg lg:hidden">{[['Home', <HomeIcon size={19} />], ['Songs', <Music2 size={19} />], ['Videos', <Video size={19} />], ['Shorts', <Zap size={19} />], ['Library', <Library size={19} />]].map(([label, icon]) => <button type="button" key={label as string} data-testid={`mobile-nav-${(label as string).toLowerCase()}`} onClick={() => setActive(label as string)} className={`flex min-w-[54px] flex-col items-center gap-1 py-1 text-[10px] font-bold ${(active === label ? 'text-[#ed704e]' : 'text-[#92909a]')}`}>{icon}<span>{label}</span></button>)}</nav>;
}

function MobileMenu({ active, setActive, onUpload, onClose }: { active: string; setActive: (v: string) => void; onUpload: () => void; onClose: () => void }) {
  const items = [
    ['Home', <HomeIcon size={18} />],
    ['Songs', <Music2 size={18} />],
    ['Videos', <Video size={18} />],
    ['Shorts', <Zap size={18} />],
    ['Library', <Library size={18} />],
  ] as const;

  return <div className="fixed inset-0 z-50 bg-[#252941]/55 p-4 backdrop-blur-sm lg:hidden" onClick={onClose}>
    <div role="dialog" aria-modal="true" aria-label="Navigation menu" className="page-in w-full max-w-xs rounded-2xl bg-[#252941] p-4 text-[#fffaf3] shadow-2xl" onClick={(event) => event.stopPropagation()}>
      <div className="mb-4 flex items-center justify-between px-2">
        <div><p className="aahil-display text-lg font-extrabold">aahil noori</p><p className="aahil-mono text-[9px] uppercase tracking-[.18em] text-[#a5a8b5]">music channel</p></div>
        <IconButton label="close-menu" onClick={onClose}><X size={18} /></IconButton>
      </div>
      <nav className="space-y-1">{items.map(([label, icon]) => <NavItem key={label} label={label} icon={icon} active={active === label} onClick={() => { setActive(label); onClose(); }} />)}</nav>
      <button type="button" data-testid="button-upload-mobile-menu" onClick={() => { onUpload(); onClose(); }} className="mt-5 flex w-full items-center justify-center gap-2 rounded-xl bg-[#ed704e] py-3 text-sm font-bold text-[#fffaf3]"><Plus size={15} /> Upload</button>
    </div>
  </div>;
}

function QueuePanel({ tracks, onPlay, onClose }: { tracks: Track[]; onPlay: (track: Track) => void; onClose: () => void }) {
  return <div role="dialog" aria-label="Play queue" className="fixed right-3 top-[82px] z-40 w-[min(360px,calc(100vw-24px))] rounded-2xl border border-[#e3d7ca] bg-[#fffaf3] p-4 shadow-2xl sm:right-7">
    <div className="mb-3 flex items-center justify-between"><div><p className="aahil-mono text-[10px] uppercase tracking-[.18em] text-[#ed704e]">Up next</p><h3 className="mt-1 font-bold text-[#252941]">Play queue</h3></div><IconButton label="close-queue" onClick={onClose}><X size={17} /></IconButton></div>
    <div className="max-h-64 space-y-1 overflow-y-auto">{tracks.slice(0, 6).map((track) => <button type="button" key={track.id} onClick={() => { onPlay(track); onClose(); }} className="flex w-full items-center gap-3 rounded-xl p-2 text-left transition hover:bg-[#f5ede3]"><div className="h-10 w-10 overflow-hidden rounded-lg"><img src={track.image} alt="" className="h-full w-full object-cover" /></div><div className="min-w-0 flex-1"><p className="truncate text-sm font-bold text-[#252941]">{track.title}</p><p className="truncate text-xs text-[#8b8790]">{track.artist}</p></div><Play size={14} className="text-[#ed704e]" fill="currentColor" /></button>)}</div>
  </div>;
}

function UploadModal({ onClose, onAdd }: { onClose: () => void; onAdd: (input: { file: File; title: string; description: string; kind: 'Song' | 'Video' }) => Promise<void> }) {
  const [title, setTitle] = useState('');
  const [kind, setKind] = useState<'Song' | 'Video'>('Song');
  const [description, setDescription] = useState('');
  const [file, setFile] = useState<File | null>(null);
  const [uploading, setUploading] = useState(false);
  const [error, setError] = useState('');
  const submit = async () => {
    if (!title.trim() || !file || uploading) return;
    setUploading(true);
    setError('');
    try {
      await onAdd({ file, title: title.trim(), description, kind });
      onClose();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Upload failed. Your existing uploads were not changed.');
    } finally {
      setUploading(false);
    }
  };
  return <div className="fixed inset-0 z-50 flex items-end justify-center bg-[#252941]/55 p-0 backdrop-blur-sm sm:items-center sm:p-5"><div role="dialog" aria-modal="true" className="page-in w-full max-w-lg rounded-t-[28px] bg-[#fbf5ec] p-6 shadow-2xl sm:rounded-[28px]"><div className="mb-6 flex items-center justify-between"><div><p className="aahil-mono text-[10px] uppercase tracking-[.2em] text-[#ed704e]">New entry</p><h2 className="aahil-display mt-1 text-2xl font-extrabold text-[#252941]">Put your voice in the room.</h2></div><IconButton label="close-upload" onClick={onClose}><X size={20} /></IconButton></div><label className="mb-2 block text-xs font-bold uppercase tracking-[.14em] text-[#777582]" htmlFor="upload-title">Title</label><input id="upload-title" data-testid="input-upload-title" value={title} onChange={(e) => setTitle(e.target.value)} placeholder="e.g. A soft morning riyaz" className="focus-ring mb-4 w-full rounded-xl border border-[#ded1c4] bg-[#fffaf3] px-4 py-3 text-sm outline-none placeholder:text-[#aaa09a]" /><label className="mb-2 block text-xs font-bold uppercase tracking-[.14em] text-[#777582]" htmlFor="upload-description">Description</label><textarea id="upload-description" value={description} onChange={(e) => setDescription(e.target.value)} placeholder="Tell listeners what this is." className="focus-ring mb-5 min-h-20 w-full resize-y rounded-xl border border-[#ded1c4] bg-[#fffaf3] px-4 py-3 text-sm outline-none placeholder:text-[#aaa09a]" /><div className="mb-5 flex gap-2"><button type="button" onClick={() => setKind('Song')} data-testid="button-upload-song" className={`flex-1 rounded-xl border py-3 text-sm font-bold ${kind === 'Song' ? 'border-[#ed704e] bg-[#ed704e]/10 text-[#d65e3d]' : 'border-[#ded1c4] text-[#777582]'}`}>Audio / song</button><button type="button" onClick={() => setKind('Video')} data-testid="button-upload-video" className={`flex-1 rounded-xl border py-3 text-sm font-bold ${kind === 'Video' ? 'border-[#ed704e] bg-[#ed704e]/10 text-[#d65e3d]' : 'border-[#ded1c4] text-[#777582]'}`}>Video</button></div><label data-testid="label-upload-file" className="mb-4 flex cursor-pointer items-center gap-3 rounded-xl border border-dashed border-[#cfc0b0] bg-[#f6eee4] px-4 py-4"><div className="flex h-9 w-9 items-center justify-center rounded-lg bg-[#f5c35c]/30 text-[#8d7028]"><Upload size={17} /></div><div className="min-w-0"><p className="text-sm font-bold text-[#252941]">{file?.name || 'Choose a media file'}</p><p className="text-xs text-[#8b8790]">Audio or video · storage-backed</p></div><input data-testid="input-upload-file" type="file" accept="audio/*,video/*" className="hidden" onChange={(e) => setFile(e.target.files?.[0] || null)} /></label>{error && <p role="alert" className="mb-4 rounded-lg bg-[#fbe2d9] px-3 py-2 text-xs font-semibold text-[#a43e27]">{error}</p>}<button type="button" disabled={!title.trim() || !file || uploading} onClick={() => { void submit(); }} data-testid="button-publish-upload" className="flex w-full items-center justify-center gap-2 rounded-xl bg-[#ed704e] py-3.5 text-sm font-bold text-[#fffaf3] transition hover:bg-[#dc6140] disabled:cursor-not-allowed disabled:opacity-40">{uploading ? 'Uploading securely…' : <><Send size={16} /> Add to channel</>}</button></div></div>;
}

function Player({ track, liked, onLike, onClose, onComment, onShare, onVideoError }: { track: Track; liked: boolean; onLike: (id: string) => void; onClose: () => void; onComment: () => void; onShare: () => void; onVideoError: () => void }) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [volume, setVolume] = useState(0.85);
  const [mediaError, setMediaError] = useState(false);

  useEffect(() => {
    const media = videoRef.current;
    if (!media) return;
    media.muted = false;
    media.defaultMuted = false;
    media.volume = 0.85;
    setIsPlaying(false);
    setIsMuted(false);
    setVolume(0.85);
    setMediaError(false);
  }, [track.id]);

  useEffect(() => {
    const media = videoRef.current;
    if (!media) return;
    media.muted = isMuted;
    media.volume = isMuted ? 0 : volume;
  }, [isMuted, volume]);

  const togglePlayback = () => {
    const media = videoRef.current;
    if (!media) return;

    if (media.paused) {
      const nextVolume = volume > 0 ? volume : 0.85;
      media.muted = false;
      media.defaultMuted = false;
      media.volume = nextVolume;
      setIsMuted(false);
      setVolume(nextVolume);
      setMediaError(false);
      void media.play().then(() => setIsPlaying(true)).catch(() => {
        setIsPlaying(false);
        setMediaError(true);
        onVideoError();
      });
    } else {
      media.pause();
      setIsPlaying(false);
    }
  };

  const toggleMute = () => {
    const media = videoRef.current;
    const nextMuted = !isMuted;
    setIsMuted(nextMuted);
    if (media) {
      media.muted = nextMuted;
      if (!nextMuted && media.volume === 0) {
        media.volume = 0.85;
        setVolume(0.85);
      }
    }
  };

  const changeVolume = (value: number) => {
    const nextVolume = Math.min(1, Math.max(0, value));
    const nextMuted = nextVolume === 0;
    setVolume(nextVolume);
    setIsMuted(nextMuted);
    if (videoRef.current) {
      videoRef.current.volume = nextVolume;
      videoRef.current.muted = nextMuted;
    }
  };

  return <div className="fixed inset-x-0 bottom-0 z-30 border-t border-[#403f51] bg-[#252941]/[.98] px-3 py-3 text-[#fffaf3] shadow-[0_-12px_32px_rgba(37,41,65,.18)] backdrop-blur-xl">
    <div className="mx-auto flex max-w-[1400px] items-center gap-2 sm:gap-3">
      <div className="hidden h-11 w-11 overflow-hidden rounded-lg sm:block"><img src={track.image} alt="" className="h-full w-full object-cover" /></div>
      <div className="min-w-0 w-[100px] sm:w-[220px]"><p className="truncate text-sm font-bold">{track.title}</p><p className="truncate text-[11px] text-[#afb1bd]">{track.artist} · {track.duration}</p></div>
      <div className="min-w-0 flex-1">
        <div className="relative overflow-hidden rounded-md bg-[#161827]">
          <video
            ref={videoRef}
            data-testid="video-player"
            className="block aspect-video h-auto w-full min-w-0 bg-[#161827] object-contain"
            controls
            playsInline
            preload="metadata"
            muted={false}
             poster={track.posterUrl || sampleVideoPoster}
             src={track.mediaUrl || sampleVideoUrl}
            onPlay={() => setIsPlaying(true)}
            onPause={() => setIsPlaying(false)}
            onLoadedData={() => setMediaError(false)}
            onVolumeChange={(event) => {
              setVolume(event.currentTarget.volume);
              setIsMuted(event.currentTarget.muted || event.currentTarget.volume === 0);
            }}
            onError={() => {
              setMediaError(true);
              onVideoError();
            }}
          />
          {!isPlaying && !mediaError && <button type="button" data-testid="button-player-play" aria-label="Play audio and video" onClick={togglePlayback} className="absolute left-1/2 top-1/2 flex -translate-x-1/2 -translate-y-1/2 items-center gap-2 rounded-full bg-[#ed704e] px-3 py-2 text-xs font-bold text-[#fffaf3] shadow-lg transition hover:bg-[#f17f60]"><Play size={16} fill="currentColor" /><span className="hidden sm:inline">Play</span></button>}
          {mediaError && <div className="absolute inset-0 flex items-center justify-center bg-[#161827]/80 px-3 text-center text-xs font-semibold text-[#fffaf3]">Audio could not load. Check your connection and try again.</div>}
        </div>
        <div className="mt-1 flex items-center gap-2">
          <button type="button" data-testid="button-player-mute" aria-label={isMuted ? 'Unmute player' : 'Mute player'} title={isMuted ? 'Unmute player' : 'Mute player'} onClick={toggleMute} className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full text-[#f5c35c] transition hover:bg-[#3a3e56]">{isMuted ? <VolumeX size={15} /> : <Volume2 size={15} />}</button>
          <input aria-label="Player volume" data-testid="input-player-volume" type="range" min="0" max="1" step="0.05" value={isMuted ? 0 : volume} onChange={(event) => changeVolume(Number(event.target.value))} className="h-1 w-20 accent-[#f5c35c] sm:w-28" />
          <span className="hidden text-[10px] font-semibold text-[#afb1bd] sm:inline">{isMuted ? 'Muted' : 'Sound on'}</span>
        </div>
      </div>
      <div className="flex items-center gap-0 sm:gap-1"><IconButton label="like-now-playing" active={liked} onClick={() => onLike(track.id)}><Heart size={17} fill={liked ? 'currentColor' : 'none'} /></IconButton><IconButton label="comment-now-playing" onClick={onComment}><MessageCircle size={17} /></IconButton><IconButton label="share-now-playing" onClick={() => { void onShare(); }}><Share2 size={17} /></IconButton><IconButton label="close-player" onClick={onClose}><X size={17} /></IconButton></div>
    </div>
  </div>;
}

function storedMediaToTrack(media: StoredMedia): Track {
  const kind: Track['kind'] = media.mediaType === 'short'
    ? 'Short'
    : media.mediaType === 'video'
      ? 'Video'
      : 'Song';
  return {
    id: media.id,
    persistentId: media.id,
    title: media.title,
    artist: media.owner?.displayName || 'Aahil Listener',
    meta: `uploaded ${new Date(media.createdAt).toLocaleDateString()}`,
    image: media.thumbnailUrl || 'https://images.pexels.com/photos/1105666/pexels-photo-1105666.jpeg?auto=compress&cs=tinysrgb&w=1000',
    duration: '',
    kind,
    accent: '#ed704e',
    mediaUrl: media.streamUrl,
    posterUrl: media.thumbnailUrl || undefined,
    mediaType: media.mediaType,
  };
}

function AuthControls() {
  const { user } = useUser();
  const { signOut } = useClerk();
  if (user) {
    return <button type="button" onClick={() => { void signOut(); }} className="hidden items-center gap-2 rounded-full border border-[#ded1c4] bg-[#fbf6ee] px-3 py-2 text-xs font-bold text-[#252941] transition hover:border-[#ed704e] sm:flex" title="Sign out"><img src={user.imageUrl} alt="" className="h-6 w-6 rounded-full object-cover" /> Sign out</button>;
  }
  return <div className="hidden items-center gap-2 sm:flex"><Link href="/sign-in" className="text-xs font-bold text-[#777582] hover:text-[#ed704e]">Sign in</Link><Link href="/sign-up" className="rounded-full bg-[#252941] px-3 py-2 text-xs font-bold text-[#fffaf3] hover:bg-[#30344c]">Join</Link></div>;
}

function Home() {
  const { isSignedIn } = useAuth();
  const [active, setActive] = useState('Home');
  const [category, setCategory] = useState('For you');
  const [query, setQuery] = useState('');
  const [liked, setLiked] = useState<string[]>(['khwaab']);
  const [saved, setSaved] = useState<string[]>([]);
  const [selectedTrack, setSelectedTrack] = useState<Track | null>(null);
  const [uploadOpen, setUploadOpen] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [queueOpen, setQueueOpen] = useState(false);
  const [userTracks, setUserTracks] = useState<Track[]>([]);
  const [persistentTracks, setPersistentTracks] = useState<Track[]>([]);
  const [comment, setComment] = useState('');
  const [comments, setComments] = useState<string[]>(['This chorus has been living in my head all week.']);
  const [commentsOpen, setCommentsOpen] = useState(false);
  const [toast, setToast] = useState('');
  useEffect(() => {
    void fetchStoredMedia(query).then(({ media }) => setPersistentTracks(media.map(storedMediaToTrack))).catch(() => {
      // Demo content remains available when the API is offline.
    });
  }, [query]);

  useEffect(() => {
    if (!isSignedIn) {
      setSaved([]);
      return;
    }
    void fetchLibrary().then(({ media }) => setSaved(media.map((item) => item.id))).catch(() => {
      setNotice('Sign in again to load your library');
    });
  }, [isSignedIn]);

  const allTracks = [...persistentTracks, ...userTracks, ...tracks];
  const filtered = useMemo(() => allTracks.filter((track) => {
    const matchesCategory = category === 'For you'
      || (category === 'Songs' && track.kind === 'Song')
      || (category === 'Videos' && track.kind === 'Video')
      || (category === 'Shorts' && track.kind === 'Short')
      || (category === 'Live sessions' && track.kind === 'Live')
      || (category === 'Sufi nights' && ['Mahi Raza', 'Zoya Mir', 'The Noori Collective'].includes(track.artist));
    return matchesCategory && `${track.title} ${track.artist}`.toLowerCase().includes(query.trim().toLowerCase());
  }), [allTracks, category, query]);
  const setNotice = (message: string) => { setToast(message); window.setTimeout(() => setToast(''), 2200); };
  const toggleLike = (id: string) => {
    const nextLiked = !liked.includes(id);
    setLiked((items) => nextLiked ? [...items, id] : items.filter((x) => x !== id));
    if (persistentTracks.some((item) => item.id === id)) {
      void setMediaLiked(id, nextLiked).catch(() => setNotice('Sign in to save likes'));
    }
    setNotice(nextLiked ? 'Added your like' : 'Removed your like');
  };
  const toggleSave = (id: string) => {
    const nextSaved = !saved.includes(id);
    setSaved((items) => nextSaved ? [...items, id] : items.filter((x) => x !== id));
    if (persistentTracks.some((item) => item.id === id)) {
      void setLibrarySaved(id, nextSaved).catch(() => setNotice('Sign in to save your library'));
    }
    setNotice(nextSaved ? 'Saved to your library' : 'Removed from your library');
  };
  const play = (track: Track) => setSelectedTrack(track);
  const addComment = () => { if (!comment.trim()) return; setComments((items) => [comment.trim(), ...items]); setComment(''); setNotice('Comment added'); };
  const openUpload = () => {
    if (!isSignedIn) {
      setNotice('Sign in before uploading your voice');
      return;
    }
    setUploadOpen(true);
  };
  const handleUpload = async (input: { file: File; title: string; description: string; kind: 'Song' | 'Video' }) => {
    const media = await uploadMedia({
      file: input.file,
      title: input.title,
      description: input.description,
      mediaType: input.kind === 'Video' ? 'video' : 'song',
    });
    setPersistentTracks((items) => [storedMediaToTrack(media), ...items]);
    setNotice('Your entry is now in the room');
  };
  const navTo = (label: string) => { setActive(label); setCategory(label === 'Home' ? 'For you' : label === 'Live' ? 'Live sessions' : label); setMobileMenuOpen(false); window.scrollTo({ top: 0, behavior: 'smooth' }); };
  const shownTracks = active === 'Library' ? allTracks.filter((t) => saved.includes(t.id)) : filtered;
  return <div className="grain aahil-shell page-in">
    <Sidebar active={active} setActive={navTo} onUpload={openUpload} />
    <main className="mobile-bottom-safe min-h-[100dvh] lg:pl-[224px]">
      <header className="sticky top-0 z-20 flex h-[74px] items-center gap-3 border-b border-[#e7dbce]/80 bg-[#f8f1e7]/90 px-4 backdrop-blur-xl sm:px-7 lg:px-10">
        <button type="button" aria-label="Open menu" data-testid="button-open-menu" onClick={() => setMobileMenuOpen(true)} className="flex h-10 w-10 items-center justify-center rounded-full text-[#252941] transition hover:bg-[#eee4d8] lg:hidden"><Menu size={21} /></button>
        <div className="relative max-w-xl flex-1"><Search className="absolute left-4 top-1/2 -translate-y-1/2 text-[#98939a]" size={17} /><input type="search" data-testid="input-search" value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Search songs, artists, moods..." className="focus-ring h-11 w-full rounded-full border border-[#e5dace] bg-[#fbf6ee] pl-11 pr-10 text-sm text-[#252941] outline-none placeholder:text-[#aaa29b]" />{query && <button type="button" data-testid="button-clear-search" onClick={() => setQuery('')} className="absolute right-3 top-1/2 -translate-y-1/2 text-[#9b9290]"><X size={16} /></button>}</div>
        <div className="hidden items-center gap-1 sm:flex"><IconButton label="notifications" onClick={() => setNotice('You are all caught up')}><Bell size={18} /></IconButton><IconButton label="queue" active={queueOpen} onClick={() => setQueueOpen((open) => !open)}><ListMusic size={18} /></IconButton></div><button type="button" onClick={openUpload} data-testid="button-upload-header" className="hidden items-center gap-2 rounded-full bg-[#252941] px-4 py-2.5 text-xs font-bold text-[#fffaf3] transition hover:bg-[#30344c] sm:flex"><Plus size={15} /> Upload</button><AuthControls />
      </header>
      {queueOpen && <QueuePanel tracks={allTracks} onPlay={play} onClose={() => setQueueOpen(false)} />}
      <div className="mx-auto max-w-[1400px] px-4 py-5 sm:px-7 sm:py-7 lg:px-10">
        <section className="hero-glow relative overflow-hidden rounded-[26px] px-5 py-6 text-[#fffaf3] sm:px-8 sm:py-9 lg:px-12 lg:py-11">
          <div className="absolute -right-20 -top-24 h-72 w-72 rounded-full border-[34px] border-[#f5c35c]/10" /><div className="absolute -bottom-40 right-20 h-72 w-72 rounded-full border-[2px] border-[#ed704e]/20" />
          <div className="relative z-10 grid items-center gap-8 lg:grid-cols-[1.12fr_.88fr]">
            <div className="stagger-in"><div className="mb-5 flex items-center gap-2"><span className="flex h-7 w-7 items-center justify-center rounded-lg bg-[#ed704e]"><Sparkles size={14} /></span><span className="aahil-mono text-[10px] font-bold uppercase tracking-[.2em] text-[#f5c35c]">The Aahil Noori channel</span></div><h1 className="aahil-display max-w-xl text-[clamp(2.4rem,6vw,5.4rem)] font-extrabold leading-[.94]">Songs that<br /><span className="text-[#f5c35c]">stay with you.</span></h1><p className="mt-5 max-w-md text-sm leading-relaxed text-[#c8cad2] sm:text-base">A little room for big voices, late-night riyaaz, and the songs we send to people we love.</p><div className="mt-7 flex flex-wrap items-center gap-3"><button type="button" onClick={() => play(tracks[0])} data-testid="button-hero-play" className="flex items-center gap-2 rounded-full bg-[#ed704e] px-5 py-3 text-sm font-bold text-[#fffaf3] transition hover:bg-[#f17f60]"><Play size={16} fill="currentColor" /> Play featured</button><button type="button" onClick={() => navTo('Songs')} data-testid="button-hero-browse" className="flex items-center gap-2 rounded-full border border-[#65697b] px-5 py-3 text-sm font-bold text-[#e7e5de] transition hover:border-[#f5c35c] hover:text-[#f5c35c]">Browse the room <ChevronDown size={15} /></button></div></div>
            <div className="stagger-in delay-2 relative mx-auto w-full max-w-sm lg:ml-auto"><div className="cover-shine relative aspect-[1.28] overflow-hidden rounded-2xl shadow-2xl"><img src={tracks[0].image} alt="Noor-e-Ishq performance" className="h-full w-full object-cover" /><div className="absolute inset-0 bg-gradient-to-t from-[#161827]/90 via-[#252941]/10 to-transparent" /><div className="absolute bottom-5 left-5"><p className="aahil-mono text-[10px] uppercase tracking-[.2em] text-[#f5c35c]">Featured session</p><p className="aahil-display mt-1 text-2xl font-bold">Noor-e-Ishq</p><p className="mt-1 text-xs text-[#cccdd3]">Aahil Noori · live from Studio 03</p></div><PlayButton onClick={() => play(tracks[0])} /></div><div className="absolute -bottom-3 -right-3 flex items-center gap-2 rounded-xl border border-[#55596d] bg-[#30334a] px-3 py-2 text-xs text-[#d6d5d3] shadow-xl"><span className="sound-bars flex h-4 items-end gap-1 text-[#ed704e]"><span style={{ height: '9px' }} /><span style={{ height: '15px' }} /><span style={{ height: '11px' }} /><span style={{ height: '6px' }} /></span> Now playing</div></div>
          </div>
        </section>
        <div className="no-scrollbar flex gap-2 overflow-x-auto py-6">{categories.map((item) => <button type="button" key={item} data-testid={`filter-${item.toLowerCase().replaceAll(' ', '-')}`} onClick={() => { setCategory(item); setActive(item === 'For you' ? 'Home' : item === 'Live sessions' ? 'Home' : item); }} className={`whitespace-nowrap rounded-full px-4 py-2.5 text-xs font-bold transition ${category === item ? 'bg-[#252941] text-[#fffaf3]' : 'border border-[#e3d7ca] bg-[#fbf6ee] text-[#777582] hover:border-[#ed704e] hover:text-[#d65e3d]'}`}>{item}</button>)}</div>
        {active === 'Library' ? <section className="stagger-in"><div className="mb-5 flex items-end justify-between"><div><p className="aahil-mono text-[10px] font-bold uppercase tracking-[.2em] text-[#ed704e]">Your collection</p><h2 className="aahil-display mt-1 text-3xl font-extrabold text-[#252941]">Saved for later<span className="text-[#ed704e]">.</span></h2></div><span className="text-xs text-[#8a8586]">{shownTracks.length} saved</span></div>{shownTracks.length ? <div className="grid grid-cols-1 gap-x-5 gap-y-8 min-[500px]:grid-cols-2 xl:grid-cols-4">{shownTracks.map((track) => <TrackCard key={track.id} track={track} onPlay={play} liked={liked.includes(track.id)} onLike={toggleLike} saved={saved.includes(track.id)} onSave={toggleSave} />)}</div> : <div className="flex min-h-[280px] flex-col items-center justify-center rounded-2xl border border-dashed border-[#d6c8b9] bg-[#fbf6ee] text-center"><div className="mb-4 flex h-14 w-14 items-center justify-center rounded-2xl bg-[#f1e1d2] text-[#ed704e]"><Bookmark size={24} /></div><h3 className="font-bold text-[#252941]">Your library is still warm</h3><p className="mt-1 max-w-xs text-sm text-[#8a8586]">Tap the bookmark on any song and it will meet you here.</p></div>}</section> : <>
          <section className="stagger-in delay-1"><div className="mb-5 flex items-end justify-between"><div><p className="aahil-mono text-[10px] font-bold uppercase tracking-[.2em] text-[#ed704e]">A good place to start</p><h2 className="aahil-display mt-1 text-3xl font-extrabold text-[#252941] sm:text-4xl">Made for your ears<span className="text-[#ed704e]">.</span></h2></div><button type="button" onClick={() => navTo('Songs')} data-testid="button-see-all-tracks" className="flex items-center gap-1 text-xs font-bold text-[#d65e3d]">See all <ChevronDown size={14} className="-rotate-90" /></button></div>{shownTracks.length ? <div className="grid grid-cols-1 gap-x-5 gap-y-8 min-[500px]:grid-cols-2 xl:grid-cols-4">{shownTracks.slice(0, 4).map((track) => <TrackCard key={track.id} track={track} onPlay={play} liked={liked.includes(track.id)} onLike={toggleLike} saved={saved.includes(track.id)} onSave={toggleSave} />)}</div> : <div className="rounded-2xl bg-[#fbf6ee] p-8 text-center text-sm text-[#777582]">No songs found for “{query}”. Try another melody.</div>}</section>
          <section className="stagger-in delay-2 mt-14 grid gap-8 xl:grid-cols-[1.2fr_.8fr]"><div><div className="mb-5 flex items-end justify-between"><div><p className="aahil-mono text-[10px] font-bold uppercase tracking-[.2em] text-[#ed704e]">Meet the voices</p><h2 className="aahil-display mt-1 text-3xl font-extrabold text-[#252941]">Featured singers<span className="text-[#ed704e]">.</span></h2></div><button type="button" data-testid="button-view-singers" onClick={() => setNotice('More voices are joining soon')} className="text-xs font-bold text-[#d65e3d]">View all</button></div><div className="flex gap-4 overflow-x-auto pb-2">{singers.map((singer) => <button type="button" key={singer.name} data-testid={`singer-${singer.name.toLowerCase().replaceAll(' ', '-')}`} onClick={() => { setQuery(singer.name); setCategory('For you'); setActive('Home'); setNotice(`Showing ${singer.name}`); }} className="group min-w-[112px] text-center"><div className="relative mx-auto h-24 w-24 overflow-hidden rounded-full border-4 border-[#f8f1e7] shadow-[0_0_0_1px_#dfd2c5] transition-transform group-hover:-translate-y-1"><img src={singer.image} alt={singer.name} className="h-full w-full object-cover" /><span className="absolute bottom-1 right-1 h-4 w-4 rounded-full border-2 border-[#f8f1e7]" style={{ backgroundColor: singer.color }} /></div><p className="mt-3 truncate text-sm font-bold text-[#252941]">{singer.name}</p><p className="mt-1 text-[11px] text-[#89848a]">{singer.role}</p></button>)}</div></div>
            <div className="rounded-2xl bg-[#e8d9c9] p-5 sm:p-6"><div className="mb-7 flex items-start justify-between"><div><p className="aahil-mono text-[10px] font-bold uppercase tracking-[.2em] text-[#a56a51]">This week</p><h2 className="aahil-display mt-1 text-2xl font-extrabold text-[#252941]">Latest songs</h2></div><div className="flex h-10 w-10 items-center justify-center rounded-xl bg-[#252941] text-[#f5c35c]"><Disc3 size={20} /></div></div><div className="space-y-4">{tracks.slice(1, 4).map((track, index) => <button type="button" key={track.id} onClick={() => play(track)} data-testid={`latest-song-${track.id}`} className="group flex w-full items-center gap-3 text-left"><span className="aahil-mono w-4 text-xs text-[#9e897e]">0{index + 1}</span><div className="h-11 w-11 overflow-hidden rounded-lg"><img src={track.image} alt="" className="h-full w-full object-cover transition group-hover:scale-110" /></div><div className="min-w-0 flex-1"><p className="truncate text-sm font-bold text-[#252941]">{track.title}</p><p className="truncate text-xs text-[#8c7e7b]">{track.artist}</p></div><span className="aahil-mono text-[10px] text-[#8c7e7b]">{track.duration}</span><Play size={15} className="text-[#ed704e] opacity-0 transition group-hover:opacity-100" fill="currentColor" /></button>)}</div><button type="button" onClick={() => navTo('Songs')} data-testid="button-open-latest" className="mt-7 flex items-center gap-2 text-xs font-bold text-[#d65e3d]">Open song shelf <ChevronDown size={14} className="-rotate-90" /></button></div></section>
          <section className="stagger-in delay-3 mt-14 overflow-hidden rounded-2xl bg-[#252941] p-6 text-[#fffaf3] sm:p-8"><div className="grid items-center gap-7 lg:grid-cols-[1fr_auto]"><div><div className="mb-3 flex items-center gap-2 text-[#f5c35c]"><Radio size={16} /><span className="aahil-mono text-[10px] font-bold uppercase tracking-[.2em]">From the archive</span></div><h2 className="aahil-display max-w-lg text-3xl font-extrabold leading-tight sm:text-4xl">The songs between the songs.</h2><p className="mt-3 max-w-lg text-sm leading-relaxed text-[#b9bbc4]">Unplugged takes, voice notes, and those after-hours sessions that never make it to a formal release.</p></div><button type="button" onClick={() => { setCategory('Live sessions'); setActive('Home'); }} data-testid="button-explore-archive" className="flex w-fit items-center gap-2 rounded-full bg-[#f5c35c] px-5 py-3 text-sm font-bold text-[#252941] transition hover:bg-[#ffd677]">Explore archive <ArrowRightIcon /></button></div></section>
        </>}
        <section className="mt-14 border-t border-[#e2d5c8] pt-7"><div className="flex items-center gap-2 text-[#8e898d]"><Clock3 size={15} /><span className="text-xs">Aahil Noori · a living archive of voices</span><span className="ml-auto aahil-mono text-[10px] uppercase tracking-[.18em]">Made for the next listen</span></div></section>
      </div>
    </main>
    <MobileNav active={active} setActive={navTo} />
     {selectedTrack && <Player key={selectedTrack.id} track={selectedTrack} liked={liked.includes(selectedTrack.id)} onLike={toggleLike} onClose={() => setSelectedTrack(null)} onComment={() => setCommentsOpen(true)} onShare={() => sharePage(selectedTrack.title, setNotice)} onVideoError={() => setNotice('The sample audio could not load')} />}
    {commentsOpen && <div className="fixed bottom-[74px] right-3 z-40 w-[min(360px,calc(100vw-24px))] rounded-2xl border border-[#e3d7ca] bg-[#fffaf3] p-4 shadow-2xl sm:bottom-[78px] sm:right-6"><div className="mb-3 flex items-center justify-between"><div><p className="aahil-mono text-[10px] uppercase tracking-[.18em] text-[#ed704e]">The room is listening</p><h3 className="mt-1 font-bold text-[#252941]">Comments</h3></div><IconButton label="close-comments" onClick={() => setCommentsOpen(false)}><X size={17} /></IconButton></div><div className="mb-3 max-h-24 space-y-2 overflow-y-auto">{comments.slice(0, 3).map((item) => <p key={item} className="rounded-lg bg-[#f5ede3] px-3 py-2 text-xs leading-relaxed text-[#66636d]">{item}</p>)}</div><div className="flex gap-2"><input aria-label="Write a comment" data-testid="input-comment" value={comment} onChange={(e) => setComment(e.target.value)} onKeyDown={(e) => e.key === 'Enter' && addComment()} placeholder="Leave a thought..." className="focus-ring min-w-0 flex-1 rounded-lg border border-[#e3d7ca] bg-[#fffaf3] px-3 py-2 text-xs outline-none" /><button type="button" data-testid="button-submit-comment" onClick={addComment} className="flex h-9 w-9 items-center justify-center rounded-lg bg-[#ed704e] text-[#fffaf3]"><Send size={15} /></button></div></div>}
     {uploadOpen && <UploadModal onClose={() => setUploadOpen(false)} onAdd={handleUpload} />}
     {mobileMenuOpen && <MobileMenu active={active} setActive={navTo} onUpload={openUpload} onClose={() => setMobileMenuOpen(false)} />}
    {toast && <div role="status" data-testid="status-toast" className="fixed bottom-24 left-1/2 z-50 flex -translate-x-1/2 items-center gap-2 rounded-full bg-[#252941] px-4 py-3 text-xs font-bold text-[#fffaf3] shadow-xl sm:bottom-7"><Check size={14} className="text-[#f5c35c]" />{toast}</div>}
  </div>;
}

function ArrowRightIcon() { return <span aria-hidden="true" className="text-base">↗</span>; }

function Router() {
  return <RoutedErrorBoundary><Switch><Route path="/sign-in"><div className="flex min-h-screen items-center justify-center bg-[#f8f1e7] p-5"><SignIn routing="hash" fallbackRedirectUrl="/" appearance={{ baseTheme: shadcn }} /></div></Route><Route path="/sign-up"><div className="flex min-h-screen items-center justify-center bg-[#f8f1e7] p-5"><SignUp routing="hash" fallbackRedirectUrl="/" appearance={{ baseTheme: shadcn }} /></div></Route><Route path="/" component={Home} /><Route component={NotFound} /></Switch></RoutedErrorBoundary>;
}

function RoutedErrorBoundary({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  return <ErrorBoundary resetKey={location}>{children}</ErrorBoundary>;
}

function App() {
  if (!clerkPubKey) {
    return <div className="flex min-h-screen items-center justify-center bg-[#252941] p-6 text-center text-sm text-[#fffaf3]">Authentication is not configured for this environment.</div>;
  }
  return <ClerkProvider publishableKey={clerkPubKey} proxyUrl={clerkProxyUrl} appearance={{ baseTheme: shadcn }}><QueryClientProvider client={queryClient}><TooltipProvider><WouterRouter base={basePath}><Router /></WouterRouter><Toaster /></TooltipProvider></QueryClientProvider></ClerkProvider>;
}

export default App;