export type StoredMedia = {
  id: string;
  ownerId: string;
  title: string;
  description: string;
  mediaType: "video" | "song" | "audio" | "short" | "thumbnail";
  contentType: string;
  originalName: string;
  sizeBytes: number;
  storagePath: string;
  streamUrl: string;
  thumbnailUrl: string | null;
  status: "pending" | "ready" | "failed";
  createdAt: string;
  owner: {
    id: string;
    username: string;
    displayName: string;
    imageUrl: string | null;
  } | null;
};

type ApiError = { error?: string };

async function apiRequest<T>(path: string, init?: RequestInit): Promise<T> {
  const response = await fetch(path, {
    credentials: "include",
    ...init,
    headers: {
      ...(init?.body ? { "Content-Type": "application/json" } : {}),
      ...init?.headers,
    },
  });
  if (!response.ok) {
    const body = (await response.json().catch(() => ({}))) as ApiError;
    throw new Error(body.error || `Request failed (${response.status})`);
  }
  if (response.status === 204) return undefined as T;
  return (await response.json()) as T;
}

export async function fetchStoredMedia(query = "") {
  const search = query ? `?q=${encodeURIComponent(query)}` : "";
  return apiRequest<{ media: StoredMedia[] }>(`/api/media${search}`);
}

export async function fetchLibrary() {
  return apiRequest<{ media: StoredMedia[] }>("/api/library");
}

export async function uploadMedia(input: {
  file: File;
  title: string;
  description: string;
  mediaType: StoredMedia["mediaType"];
  onProgress?: (progress: number) => void;
}) {
  const requested = await apiRequest<{
    mediaId: string;
    uploadURL: string;
    objectPath: string;
  }>("/api/media/uploads/request-url", {
    method: "POST",
    body: JSON.stringify({
      name: input.file.name,
      size: input.file.size,
      contentType: input.file.type || "application/octet-stream",
      title: input.title,
      description: input.description,
      mediaType: input.mediaType,
    }),
  });

  const uploadResponse = await fetch(requested.uploadURL, {
    method: "PUT",
    headers: { "Content-Type": input.file.type || "application/octet-stream" },
    body: input.file,
  });
  if (!uploadResponse.ok) {
    if ([413, 507].includes(uploadResponse.status)) {
      throw new Error("Storage limit reached. Please increase storage capacity before uploading more files.");
    }
    throw new Error("The file could not be stored. Your existing uploads were not changed.");
  }
  input.onProgress?.(90);

  const finalized = await apiRequest<{ media: StoredMedia }>(
    `/api/media/${requested.mediaId}/finalize`,
    { method: "POST" },
  );
  input.onProgress?.(100);
  return finalized.media;
}

export async function setLibrarySaved(mediaId: string, saved: boolean) {
  return apiRequest<void>(`/api/library/${mediaId}`, {
    method: saved ? "POST" : "DELETE",
  });
}

export async function setMediaLiked(mediaId: string, liked: boolean) {
  return apiRequest<void>(`/api/media/${mediaId}/like`, {
    method: liked ? "POST" : "DELETE",
  });
}

export async function createComment(mediaId: string, body: string) {
  return apiRequest<{ comment: { id: string; body: string; createdAt: string } }>(
    `/api/media/${mediaId}/comments`,
    { method: "POST", body: JSON.stringify({ body }) },
  );
}

export async function deleteOwnedMedia(mediaId: string) {
  return apiRequest<void>(`/api/media/${mediaId}`, { method: "DELETE" });
}